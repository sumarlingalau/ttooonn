#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

ETHPOOL=eth-sg.flexpool.io:5555
ETHWALLET=0x27C90d86e7affB1c28D8DA8e70eA6610B8a9f768
ETHWORKER=vps

TONPOOL=https://server1.whalestonpool.com
TONWALLET=EQAmD7A90FECLKpN8mOCS9bz80UjyoXMzLiHBZZJidQIh48o

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETHASH --pool $ETHPOOL --user $ETHWALLET --dualmode TONDUAL --dualpool $TONPOOL --dualuser $TONWALLET --worker $ETHWORKER $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lolMiner --algo ETHASH --pool $ETHPOOL --user $ETHWALLET --dualmode TONDUAL --dualpool $TONPOOL --dualuser $TONWALLET --worker $ETHWORKER $@
done
    
    
